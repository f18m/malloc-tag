# malloc-tag tools

This README describes the Python-based tools to postprocess malloc-tag snapshots:

* mtag-postprocess
* mtag-json2dot

TO BE WRITTEN
